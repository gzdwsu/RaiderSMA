/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tester;

/**
 * @author Jared Murphy
 * Right now, the code in this project prints out a tournament bracket. 
 * The problem, however, is that no more than an 8-Man bracket will fit on a single page.
 * I need you to change the displayArray method so that it won't try to print brackets bigger than 8 people.
 * If there are 16 people, it should print one 8-man bracket and then print the other 8-man bracket
 * If there are 32 peiople, it should print 4 8-man brackets.
 * I posted a crap ton of comments, so all the information you need should be in here.
 * If you have any questions, snap me
 */
public class Tester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //These double slashes mean that everything after it on the same line is a comment. Comments aren't read by the machine, only people.
        //
        //This part is making a bunch of array variables. Arrays are a storage structure. Here's what each part means:
        //1: This is the data type. A String is a collection of characters, like "this". The [] after it means that it's an array OF Strings
        //2: This is the name of your variable. It can be anything except reserved words, like the ones in blue.
        //3: This basically means we're creating an array right now. It's not important for what we're doing right now.
        //4: This is the type of new array we're making, jsut like #1
        //5: These are the things you're storing in your area. In this case, they're usernames.
        //5 cont: You'll see why I made them all the same when you run this
        //1         2       3     4      5------------>
        String[] levZero = new String[]{"MurphyJar", "MurphyDyl", "MurphyZac", "MurphyBuf", "MurphyRod", "MurphySha", "KimbalAnd", "McsparGle", "MurphyJar", "MurphyDyl", "MurphyZac", "MurphyBuf", "MurphyRod", "SchnacRya", "KimbalAnd", "McsparGle"};
        String[] levOne = new String[]{"MurphyJar", "MurphyDyl", "MurphyZac", "MurphyBuf", "MurphyRod", "MurphySha", "KimbalAnd", "McsparGle"};
        String[] levTwo = new String[]{"MurphyJar", "MurphyZac", "MurphyRod", "KimbalAnd"};
        String[] levThree = new String[]{"MurphyJar", "MurphyRod"};
        String[] levFour = new String[]{"MurphyJar"};
        displayArray(levFour, 3);//This is a method call. It starts with the name of the method you want to call (displayArray), followed by your parameters in parentheses
        displayArray(levThree, 2);//If you go down to the method called "displayArray", I explain what a parameter is.
        displayArray(levTwo,1);
        displayArray(levOne, 0);
        //displayArray(levZero, 0);
        
    }
//    1: This isn't worth talking about yet since it's used at a higher level (Options are Public, Private, Protected)
//    2: This isn't worth talking about yet since it's used at a higher level (Options are static, *empty*)
//    3: This is your return type; it specifies what you should get back if you call the method. For example, if I called the following method:
    // public static int add(int numberOne, int numberTwo){
    //      return (numberOne+numberTwo);
    //}
//    3 cont: I would expect back an integer. Integers are just numbers without decimal points.
//    4: This is the name of the method. The name can be literally anything except reserved words, like the ones highlighted in blue
//    5: These are your parameters. They are the information your method is going to operate on. In our case, we have two.
//    5 cont: The first is called 'arr' and is an array of Strings. The second is called 'level' and is simply and integer.
//    1      2      3       4                   5           
    public static void displayArray(String[] arr, int level){ //This is called a Method. Look at the comment above to see what each section means
    int[] nameSpaceMatrix = new int[]{0,6,18,42,94}; //Lvl 0, Lvl 1, Lvl 2...
    int nameSpace = nameSpaceMatrix[level]; //Number of spaces between each name
    int hbarNum = arr.length/2;//Equivalent to the number of matches being wrestled during the level
    int hbarLength = 6*(int)Math.pow(2,level+1)+1; //How long the string of underscores needs to be... The math.pow part just means 2^(level+1)
    int vbarSpace = nameSpace+4; //How much space is between the edge and the first vertical bar
    int vbarNum = 5; //Number of bars to print between the name and the next level (Number of vertical bars between levels of the bracket)
    int stdSpace = 3; //On the bottom-most level, how many spaces are between each name
    
    //Print the underscores
    //This is a for() loop. For loops go through the instructions inside of them a set number of times
    //1: This is the declaration part. It'll make more sense why we need it after the next parts
    //2: This is the "Keep Going" condition. While the value of i ISN'T equal to hbarNum, the loop will keep going.
    //3: This is what allows you to break the loop. Each time it runs through every statement in this for() loop, it will perform the action in this section
    //3 cont: In this case, it will increase the value of i by one. i++ is the same as i = i+1
    //      1          2         3
    for(int i = 0;i != hbarNum; i++){ //...For every number between 0 and the value of hbarNum (Check the note above for info on for loops)
    printSpaces(vbarSpace); //Print number of spaces equal to vbarSpace
    printUnderscore(hbarLength); //print number of underscores equal to hbarLength
    printSpaces(vbarSpace + stdSpace); //print number of spaces equal to vbarSpace
    }//This ends the for() loop.
    
    System.out.println("");//System.out.println() prints whatever is in the parentheses and then it moves to the next line
    
    //Print the vertical bars
    for(int i = 0; i != vbarNum; i++){//This is called a 'nested' for loop because the one with a j lives inside the one with an i.
    for(int j = 0; j != arr.length; j++){ //Since it's nested, this will actually run vbarNum*arr.length times
        printSpaces(vbarSpace);
        System.out.print("|");
        printSpaces(vbarSpace + stdSpace);
    }//If you move your cursor to this curly brace, you'll see that the one after the beginning of the j for() loop highlights in yellow. This means they're a pair.
    System.out.println("");
    }
    
    //Print the names
    for(int i = 0; i != arr.length; i++){
        printSpaces(nameSpace);
        System.out.print(arr[i]);//System.out.print() prints whatever is in the parentheses, but doesn't add a new line.
                                 //This statement prints i(th) item in the array. For example, arr[0] is "MurphyJar"
        printSpaces(nameSpace + stdSpace);
    }
    
    System.out.println("");
    }
    
    public static void printSpaces(int n){//These are just helper methods. I separated them out so I didn't have a bunch of nested for() loops in the displayArray method.
        for(int i = 0; i != n; i++){
            System.out.print(" ");
        }
        return;
    }
    
    public static void printUnderscore(int n){
         for(int i = 0; i != n; i++){
            System.out.print("_");
        }
        return;
    }
    
}
//Questions to think about
//1)Why would I use methods?
//2)Why would I use println or print
//3)What's the difference between nameSpaceMatrix and nameSpace in the displayArray method?